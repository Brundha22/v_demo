export class Addmenu {
    foodMenuID: number = 0;
    foodMenuType: string = "";
    foodMenuItems: string = "";
    foodMenuCost: string = "";
    foodMenuImage: string = "";
}
