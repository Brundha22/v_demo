export class bookevent{
    eventid : number = 0;
    eventName:string = "";
    applicantName: string = "";
    ApplicantAddress: String="";
    applicantMobile: string = "";
    applicantEmail:string="";
    eventAddress:string="";
    eventDate:string="";
    eventTime:string="";
    eventMenuId:number=0;
    addonId:number=0;
    EventCost:String="";
}
